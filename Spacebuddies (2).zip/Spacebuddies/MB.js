@media screen and (max-width: 600px) {
    .topnav.responsive {position: relative;}
    .topnav.responsive a.icon {
      position: absolute;
      right: 0;
      top: 0;}

var website={
    author: 'Asif A. Siddiqi',
    title: 'Beyond Earth',
    published: 2018,
    roboticTravellers: ['Voyager 1 ','Voyager 2','New Horizons','Cassini', 'Akatsuki','Kepler',],

    },
   